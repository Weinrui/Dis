package com.project2.DataCollectionDispatcher.controller;

import com.project2.DataCollectionDispatcher.services.StationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DataCollectionController {

    @Autowired
    private StationService stationService;

    @PostMapping("/startDataCollection")
    public ResponseEntity<String> startDataCollection() {
        stationService.startDataGatheringJob();
        return ResponseEntity.ok("Data collection job started");
    }
}
