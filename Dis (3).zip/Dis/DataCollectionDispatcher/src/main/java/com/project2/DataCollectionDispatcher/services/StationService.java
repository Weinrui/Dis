package com.project2.DataCollectionDispatcher.services;

import com.project2.DataCollectionDispatcher.config.RabbitMQConfig;
import com.project2.DataCollectionDispatcher.entity.Station;
import com.project2.DataCollectionDispatcher.repository.StationRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class StationService {
    private static final Logger log = LoggerFactory.getLogger(StationService.class);

    @Autowired
    private StationRepository stationRepository;

    @Autowired
    private RabbitTemplate rabbitTemplate;

    public List<Station> getAllStations() {
        return stationRepository.findAll();
    }

    public void startDataGatheringJob() {
        List<Station> stations = getAllStations();
        for (Station station : stations) {
            String message = "Start data collection for station ID: " + station.getId();
            log.info("Sending message to Station Data Collector: {}", message);
            rabbitTemplate.convertAndSend(RabbitMQConfig.STATION_DATA_QUEUE_NAME, message);
        }
        String newJobMessage = "New data collection job started";
        log.info("Sending message to Data Collection Receiver: {}", newJobMessage);
        rabbitTemplate.convertAndSend(RabbitMQConfig.DATA_COLLECTION_RECEIVER_QUEUE_NAME, newJobMessage);
    }

    @RabbitListener(queues = RabbitMQConfig.INVOICE_QUEUE_NAME)
    public void handleInvoiceMessage(String message) {
        log.info("Received message from invoice queue:", message);
        // Wenn eine Nachricht in der invoice-Queue empfangen wird, starten wir den Datensammlungsjob
        startDataGatheringJob();
    }

    @RabbitListener(queues = RabbitMQConfig.STATION_DATA_QUEUE_NAME)
    public void handleStationDataMessage(String message) {
        log.info("Received message from station data queue: {}", message);
        // Hier können Sie die Logik zur Verarbeitung der Nachricht hinzufügen
    }
}
