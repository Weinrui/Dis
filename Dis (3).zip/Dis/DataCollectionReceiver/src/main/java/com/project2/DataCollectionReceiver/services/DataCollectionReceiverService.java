package com.project2.DataCollectionReceiver.services;

import com.project2.DataCollectionReceiver.model.DataCollectionJob;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class DataCollectionReceiverService {

    @Autowired
    private RabbitTemplate rabbitTemplate;

    private final Map<String, DataCollectionJob> jobs = new HashMap<>();

    @RabbitListener(queues = "dataCollectionReceiverQueue")
    public void receiveData(String message) {
        if (message.startsWith("start:")) {
            String customerId = message.split(":")[1];
            jobs.put(customerId, new DataCollectionJob(customerId));
        } else if (message.startsWith("data:")) {
            String[] parts = message.split(":");
            String customerId = parts[1];
            String data = parts[2];
            DataCollectionJob job = jobs.get(customerId);
            if (job != null) {
                job.addData(data);
                if (job.isComplete()) {
                    sendToPdfGenerator(job);
                    jobs.remove(customerId);
                }
            }
        }
    }

    private void sendToPdfGenerator(DataCollectionJob job) {
        String customerId = job.getCustomerId();
        String data = String.join(",", job.getData());
        String message = "generate:" + customerId + ":" + data;
        rabbitTemplate.convertAndSend("pdfGeneratorQueue", message);
    }
}
