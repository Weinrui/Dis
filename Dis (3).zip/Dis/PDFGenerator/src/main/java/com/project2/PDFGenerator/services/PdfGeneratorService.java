package com.project2.PDFGenerator.services;

import com.project2.PDFGenerator.entity.Customer;
import com.project2.PDFGenerator.repository.CustomerRepository;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

@Service
public class PdfGeneratorService {

    @Autowired
    private CustomerRepository customerRepository;

    @RabbitListener(queues = "pdfGeneratorQueue")
    public void generatePdf(String message) {
        String[] parts = message.split(":");
        String customerId = parts[1];
        String data = parts[2];

        Long id = Long.parseLong(customerId);
        Customer customer = customerRepository.findById(id).orElse(null);

        if (customer != null) {
            Document document = new Document();
            try {
                String directoryPath = "invoices";
                String filePath = directoryPath + "/invoice_" + customerId + ".pdf";

                // 创建目录
                File directory = new File(directoryPath);
                if (!directory.exists()) {
                    directory.mkdirs();
                }

                PdfWriter.getInstance(document, new FileOutputStream(filePath));
                document.open();
                document.add(new Paragraph("Invoice for Customer ID: " + customerId));
                document.add(new Paragraph("First Name: " + customer.getFirstname()));
                document.add(new Paragraph("Last Name: " + customer.getLastname()));
                document.add(new Paragraph("Collected Data:"));
                document.add(new Paragraph(data));
                document.close();

                // 读取文件以确保文件存在并非空
                byte[] fileContent = Files.readAllBytes(Paths.get(filePath));
                if (fileContent.length == 0) {
                    throw new IOException("Generated PDF file is empty.");
                }
            } catch (DocumentException | IOException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("Customer not found for ID: " + customerId);
        }
    }
}
