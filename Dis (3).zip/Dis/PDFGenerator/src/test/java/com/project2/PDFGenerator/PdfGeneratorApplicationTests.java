package com.project2.PDFGenerator;

import com.project2.PDFGenerator.services.PdfGeneratorService;
import com.project2.PDFGenerator.entity.Customer;
import com.project2.PDFGenerator.repository.CustomerRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.SpyBean;

import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.File;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.timeout;
import static org.mockito.Mockito.verify;

@SpringBootTest
@ExtendWith(MockitoExtension.class)
class PdfGeneratorApplicationTests {

	@Autowired
	private RabbitTemplate rabbitTemplate;

	@SpyBean
	private PdfGeneratorService pdfGeneratorService;

	@Autowired
	private CustomerRepository customerRepository;

	private Long customerId;

	@BeforeEach
	public void setUp() {
		// 清空队列
		rabbitTemplate.execute(channel -> {
			channel.queuePurge("pdfGeneratorQueue");
			return null;
		});

		// 初始化一个测试用的 Customer 对象
		Customer customer = new Customer("John", "Doe");
		customerRepository.save(customer);

		// 初始化 customerId 变量
		customerId = customer.getId();
	}

	@Test
	void testGeneratePdf() throws Exception {
		// 准备测试数据
		String data = "someData";
		String message = "generate:" + customerId + ":" + data;

		// 手动调用 PdfGeneratorService 的 generatePdf 方法
		pdfGeneratorService.generatePdf(message);

		// 验证 PdfGeneratorService 的 generatePdf 方法被调用
		verify(pdfGeneratorService, timeout(5000)).generatePdf(message);

		// 验证生成的 PDF 文件
		String filePath = "invoices/invoice_" + customerId + ".pdf";
		File pdfFile = new File(filePath);
		assertThat(pdfFile.exists()).isTrue();

		// 可选：读取 PDF 文件内容并进行进一步验证
		byte[] fileContent = Files.readAllBytes(Paths.get(filePath));
		assertThat(fileContent).isNotEmpty();
	}
}
