package com.project2.SpringBootApp.controller;

import com.project2.SpringBootApp.services.InvoiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/invoices")
public class InvoiceRequestController {

    private final InvoiceService invoiceService;

    @Autowired
    public InvoiceRequestController(InvoiceService invoiceService) {
        this.invoiceService = invoiceService;
    }

    @PostMapping("/{customerId}")
    public ResponseEntity<String> generateInvoice(@PathVariable String customerId) {
        invoiceService.startInvoiceGeneration(customerId);
        return ResponseEntity.ok("Invoice generation started for customer ID: " + customerId);
    }

    @GetMapping("/{customerId}")
    public ResponseEntity<?> getInvoice(@PathVariable String customerId) {
        return invoiceService.getInvoice(customerId);
    }
}
