package com.project2.SpringBootApp.services;

import com.project2.SpringBootApp.config.RabbitMQConfig;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Component
@Slf4j
@Service
public class InvoiceService {

    private final RabbitTemplate rabbitTemplate;

    @Autowired
    public InvoiceService(RabbitTemplate rabbitTemplate) {
        this.rabbitTemplate = rabbitTemplate;
    }

    public void startInvoiceGeneration(String customerId) {
        rabbitTemplate.convertAndSend(RabbitMQConfig.INVOICE_QUEUE_NAME, customerId);
    }

    @RabbitListener(queues = RabbitMQConfig.INVOICE_QUEUE_NAME)
    public void processMessage(String message, int messageCount) {
        log.info("Received Message #" + messageCount + ": " + message);

        // Delay
        try {
            Thread.sleep(message.length() * 1000L);
        } catch (InterruptedException e) {
            log.error("Invoice service interrupted", e);
        }

        log.info("Sent Message: Echo " + message);
    }

    public ResponseEntity<?> getInvoice(String customerId) {
        // Placeholder logic for retrieving the invoice
        // Replace this with actual implementation to check if invoice is available
        boolean invoiceAvailable = true; // This should be replaced with actual logic

        if (invoiceAvailable) {
            // Return the invoice download link
            String downloadLink = "http://localhost:8080/files/invoice_" + customerId + ".pdf";
            return ResponseEntity.ok().body("Invoice available at: " + downloadLink);
        } else {
            return ResponseEntity.status(404).body("Invoice not available yet");
        }
    }
}
