package com.project2.StationDataCollector.entity;

import jakarta.persistence.*;

@Entity
public class Charge {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private int customerId;
    private Double kwh;

    // Getter und Setter
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }



    public Double getKwh() {
        return kwh;
    }

    public void setKwh(Double kwh) {
        this.kwh = kwh;
    }

    @Override
    public String toString() {
        return "Charge{" +
                "id=" + id +
                ", customerId='" + customerId + '\'' +
                ", kWh=" + kwh +
                '}';
    }
}