package com.project2.StationDataCollector.services;

import com.project2.StationDataCollector.config.RabbitMQConfig;
import com.project2.StationDataCollector.entity.Charge;
import com.project2.StationDataCollector.repository.ChargeRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ChargeService {
    private static final Logger log = LoggerFactory.getLogger(ChargeService.class);

    @Autowired
    private ChargeRepository chargeRepository;

    @Autowired
    private RabbitTemplate rabbitTemplate;

    public Map<Long, Double> getConsumptionPerStation(int customerId) {
        List<Charge> charges = chargeRepository.findByCustomerId(customerId);
        log.info("Retrieved charges for customerId {}: {}", customerId, charges);

        // Aggregate consumption per station
        Map<Long, Double> consumptionPerStation = charges.stream()
                .collect(Collectors.groupingBy(Charge::getId,  // Assuming you want to group by Charge ID if station_id is not available
                        Collectors.summingDouble(Charge::getKwh)));

        log.info("Aggregated consumption per charge: {}", consumptionPerStation);
        return consumptionPerStation;
    }

    @RabbitListener(queues = RabbitMQConfig.STATION_DATA_QUEUE_NAME)
    public void handleStationDataMessage(String message) {
        log.info("Received message from station data queue: {}", message);

        // Extract customerId from the message
        String customerId = parseCustomerIdFromMessage(message);
        log.info("Extracted customerId: {}", customerId);

        // Retrieve data from the database based on customerId
        List<Charge> charges = chargeRepository.findByCustomerId(Integer.parseInt(customerId));
        log.info("Retrieved charges: {}", charges);

        // Process and aggregate the data
        Map<Long, Double> consumptionPerStation = charges.stream()
                .collect(Collectors.groupingBy(Charge::getId,
                        Collectors.summingDouble(Charge::getKwh)));

        log.info("Aggregated consumption per charge: {}", consumptionPerStation);

        // Convert the aggregated data to a string
        String aggregatedData = consumptionPerStation.entrySet().stream()
                .map(entry -> "Station ID: " + entry.getKey() + ", kWh: " + entry.getValue())
                .collect(Collectors.joining("; "));

        log.info("Aggregated data: {}", aggregatedData);

        // Send the aggregated data to Data Collection Receiver
        rabbitTemplate.convertAndSend(RabbitMQConfig.DATA_COLLECTION_RECEIVER_QUEUE_NAME, aggregatedData);
        log.info("Sent aggregated data to Data Collection Receiver: {}", aggregatedData);
    }

    private String parseCustomerIdFromMessage(String message) {
        // Implement the logic to extract customerId from the message
        // For simplicity, assume the message format is "Start data collection for customer ID: <customerId>"
        return message.split(":")[1].trim();
    }
}
