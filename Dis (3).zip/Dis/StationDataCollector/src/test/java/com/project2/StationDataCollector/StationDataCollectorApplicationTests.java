package com.project2.StationDataCollector.services;

import com.project2.StationDataCollector.config.RabbitMQConfig;
import com.project2.StationDataCollector.entity.Charge;
import com.project2.StationDataCollector.repository.ChargeRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class ChargeService {
	private static final Logger log = LoggerFactory.getLogger(ChargeService.class);

	@Autowired
	private ChargeRepository chargeRepository;

	@RabbitListener(queues = RabbitMQConfig.STATION_DATA_QUEUE_NAME)
	public void handleStationDataMessage(String message) {
		log.info("Received message: " + message);
		String customerId = parseCustomerIdFromMessage(message);
		Map<Long, Double> consumptionPerStation = getConsumptionPerStation(customerId);
		log.info("Consumption per station for customer {}: {}", customerId, consumptionPerStation);
	}

	private String parseCustomerIdFromMessage(String message) {
		// Hier können Sie die Logik hinzufügen, um die customerId aus der Nachricht zu extrahieren
		return message.split(":")[1].trim();
	}

	private Map<Long, Double> getConsumptionPerStation(String customerId) {
		List<Charge> charges = chargeRepository.findByCustomerId(customerId);
		return charges.stream().collect(Collectors.groupingBy(
				Charge::getStationId,
				Collectors.summingDouble(Charge::getKwh)
		));
	}
}
