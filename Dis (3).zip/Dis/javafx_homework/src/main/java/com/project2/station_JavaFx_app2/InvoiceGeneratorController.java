package com.project2.station_JavaFx_app2;

import com.project2.station_JavaFx_app2.model.Invoice;
import com.project2.station_JavaFx_app2.service.InvoiceGeneratorService;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.util.List;

public class InvoiceGeneratorController {

    @FXML
    private TextField customerIdField;

    @FXML
    private Button generateInvoiceBtn;

    @FXML
    private TableView<Invoice> invoiceTable;

    @FXML
    private TableColumn<Invoice, String> customerIdColumn;

    @FXML
    private TableColumn<Invoice, Button> viewInvoiceColumn;

    private final InvoiceGeneratorService invoiceService = new InvoiceGeneratorService();

    @FXML
    private void initialize() {
        customerIdColumn.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        viewInvoiceColumn.setCellValueFactory(new PropertyValueFactory<>("viewInvoiceButton"));
    }

    @FXML
    private void handleGenerateInvoice() {
        String customerId = customerIdField.getText();
        if (customerId.isEmpty()) {
            // Display error message
            return;
        }

        try {
            invoiceService.generateInvoice(customerId);
            checkInvoiceAvailability(customerId);
        } catch (Exception e) {
            e.printStackTrace();
            // Display error message
        }
    }

    private void checkInvoiceAvailability(String customerId) {
        new Thread(() -> {
            try {
                boolean invoiceAvailable = false;
                while (!invoiceAvailable) {
                    List<Invoice> invoices = invoiceService.checkInvoiceAvailability(customerId);
                    if (!invoices.isEmpty()) {
                        invoiceTable.getItems().setAll(invoices);
                        invoiceAvailable = true;
                    } else {
                        Thread.sleep(5000);
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                // Display error message
            }
        }).start();
    }
}
