package com.project2.DataCollectionDispatcher;

import com.project2.DataCollectionDispatcher.repository.StationRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
public class DataCollectionDispatcherApplicationTests {

    @Autowired
    private WebApplicationContext webApplicationContext;

    @Autowired
    private StationRepository stationRepository;

    private MockMvc mockMvc;

    @BeforeEach
    public void setUp() {
        this.mockMvc = MockMvcBuilders
                .webAppContextSetup(webApplicationContext)
                .build();

        // Clean up the database before each test
        stationRepository.deleteAll();
    }

    @Test
    void contextLoads() {
        // This test will fail if the application context cannot start
    }

    @Test
    void testAddingStation() throws Exception {
        String station = """
        { 
            "dbUrl": "localhost:30014",
            "lat": "48.190000",
            "lng": "16.380000"
        }  
        """;

        mockMvc.perform(post("/stations")
                        .content(station)
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isCreated());
    }
}
