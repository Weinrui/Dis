package com.project2.DataCollectionReceiver.model;

import java.io.Serializable;

public class DataCollectionJob implements Serializable {

    private Long customerId;
    private Double kwh;

    public DataCollectionJob() {}

    public DataCollectionJob(Long customerId, Double kwh) {
        this.customerId = customerId;
        this.kwh = kwh;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public Double getKwh() {
        return kwh;
    }

    public void setKwh(Double kwh) {
        this.kwh = kwh;
    }
}
