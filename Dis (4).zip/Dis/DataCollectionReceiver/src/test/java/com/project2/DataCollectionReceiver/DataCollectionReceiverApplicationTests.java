package com.project2.DataCollectionReceiver;

import com.project2.DataCollectionReceiver.services.DataCollectionReceiverService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.amqp.rabbit.test.context.SpringRabbitTest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.timeout;
import static org.mockito.Mockito.verify;

@SpringBootTest
@SpringRabbitTest
public class DataCollectionReceiverApplicationTests {

	@Autowired
	private RabbitTemplate rabbitTemplate;

	@SpyBean
	private DataCollectionReceiverService dataCollectionReceiverService;

	@BeforeEach
	public void setUp() {
		// 清空队列，确保测试的独立性
		rabbitTemplate.execute(channel -> {
			channel.queuePurge("dataCollectionReceiverQueue");
			channel.queuePurge("pdfGeneratorQueue");
			return null;
		});
	}

	@Test
	void contextLoads() {
		// 验证 Spring 应用程序上下文是否加载
	}

	@Test
	void testReceiveData() throws Exception {
		String startMessage = "start:123";
		String dataMessage = "data:123:someData";

		// 发送开始消息
		rabbitTemplate.convertAndSend("dataCollectionReceiverQueue", startMessage);
		verify(dataCollectionReceiverService, timeout(5000)).receiveData(startMessage);

		// 发送数据消息
		rabbitTemplate.convertAndSend("dataCollectionReceiverQueue", dataMessage);
		verify(dataCollectionReceiverService, timeout(5000)).receiveData(dataMessage);
	}

	@Test
	void testSendToPdfGenerator() throws Exception {
		String startMessage = "start:123";
		String dataMessage1 = "data:123:someData1";
		String dataMessage2 = "data:123:someData2";
		String dataMessage3 = "data:123:someData3";

		// 发送开始消息和数据消息
		rabbitTemplate.convertAndSend("dataCollectionReceiverQueue", startMessage);
		rabbitTemplate.convertAndSend("dataCollectionReceiverQueue", dataMessage1);
		rabbitTemplate.convertAndSend("dataCollectionReceiverQueue", dataMessage2);
		rabbitTemplate.convertAndSend("dataCollectionReceiverQueue", dataMessage3);

		// 验证 PDF 生成队列收到消息
		String expectedMessage = "generate:123:someData1,someData2,someData3";
		Object receivedMessage = rabbitTemplate.receiveAndConvert("pdfGeneratorQueue", 5000);
		assertThat(receivedMessage).isEqualTo(expectedMessage);
	}
}
