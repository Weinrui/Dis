package com.project2.SpringBootApp.model;

public class InvoiceRequest {
    private String customerId;

    // Getters and Setters
    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }
}
