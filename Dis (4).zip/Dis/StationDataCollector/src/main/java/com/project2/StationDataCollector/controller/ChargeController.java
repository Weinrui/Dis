package com.project2.StationDataCollector.controller;

import com.project2.StationDataCollector.services.ChargeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
public class ChargeController {

    @Autowired
    private ChargeService chargeService;

    @GetMapping("/consumption")
    public ResponseEntity<Map<Long, Double>> getConsumptionPerStation(@RequestParam String customerId) {
        Map<Long, Double> consumptionPerStation = chargeService.getConsumptionPerStation(Integer.parseInt(customerId));
        return ResponseEntity.ok(consumptionPerStation);
    }
}
