package com.project2.station_JavaFx_app2.model;

public class Invoice {
    private Long customerId;
    private String invoiceDetails;

    public Invoice(Long customerId, String invoiceDetails) {
        this.customerId = customerId;
        this.invoiceDetails = invoiceDetails;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getInvoiceDetails() {
        return invoiceDetails;
    }

    public void setInvoiceDetails(String invoiceDetails) {
        this.invoiceDetails = invoiceDetails;
    }
}
