package com.project2.DataCollectionDispatcher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
@EnableJpaRepositories("com.project2.DataCollectionDispatcher.repository")
@EntityScan("com.project2.DataCollectionDispatcher.entity")
public class DataCollectionDispatcherApplication {
	public static void main(String[] args) {
		SpringApplication.run(DataCollectionDispatcherApplication.class, args);
	}
}
