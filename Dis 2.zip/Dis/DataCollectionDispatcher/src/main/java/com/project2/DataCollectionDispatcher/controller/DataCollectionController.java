package com.project2.DataCollectionDispatcher.controller;

import com.project2.DataCollectionDispatcher.services.DataCollectionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/data-collection")
public class DataCollectionController {

    private final DataCollectionService dataCollectionService;

    @Autowired
    public DataCollectionController(DataCollectionService dataCollectionService) {
        this.dataCollectionService = dataCollectionService;
    }

    @PostMapping("/start/{customerId}")
    public void startDataCollection(@PathVariable String customerId) {
        dataCollectionService.startDataCollection(customerId);
    }
}
