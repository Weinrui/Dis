package com.project2.DataCollectionDispatcher.entity;

import jakarta.persistence.*;


@Entity
public class DataCollectionJob {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String customerId;
    private String status;

    public DataCollectionJob() {
    }

    public DataCollectionJob(String customerId, String status) {
        this.customerId = customerId;
        this.status = status;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
