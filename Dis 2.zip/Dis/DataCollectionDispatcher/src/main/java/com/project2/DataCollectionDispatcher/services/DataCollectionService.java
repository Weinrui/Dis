package com.project2.DataCollectionDispatcher.services;

import com.project2.DataCollectionDispatcher.config.RabbitMQConfig;
import com.project2.DataCollectionDispatcher.entity.DataCollectionJob;
import com.project2.DataCollectionDispatcher.repository.DataCollectionJobRepository;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DataCollectionService {

    private final RabbitTemplate rabbitTemplate;
    private final DataCollectionJobRepository jobRepository;

    @Autowired
    public DataCollectionService(RabbitTemplate rabbitTemplate, DataCollectionJobRepository jobRepository) {
        this.rabbitTemplate = rabbitTemplate;
        this.jobRepository = jobRepository;
    }

    public void startDataCollection(String customerId) {
        DataCollectionJob job = new DataCollectionJob(customerId, "STARTED");
        jobRepository.save(job);

        String[] stations = {"station1", "station2", "station3"};

        for (String station : stations) {
            String message = station + ":" + customerId;
            rabbitTemplate.convertAndSend(RabbitMQConfig.STATION_DATA_QUEUE_NAME, message);
        }

        String startMessage = "start:" + customerId;
        rabbitTemplate.convertAndSend(RabbitMQConfig.DATA_COLLECTION_RECEIVER_QUEUE_NAME, startMessage);
    }
}
