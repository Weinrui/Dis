package com.project2.DataCollectionDispatcher;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataCollectionDispatcherApplicationTests {

	@Test
	void contextLoads() {
	}

}
