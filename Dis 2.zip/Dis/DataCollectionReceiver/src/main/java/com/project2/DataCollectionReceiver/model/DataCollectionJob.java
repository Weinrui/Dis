package com.project2.DataCollectionReceiver.model;

import java.util.ArrayList;
import java.util.List;

public class DataCollectionJob {
    private String customerId;
    private List<String> data = new ArrayList<>();

    public DataCollectionJob(String customerId) {
        this.customerId = customerId;
    }

    public void addData(String data) {
        this.data.add(data);
    }

    public boolean isComplete() {
        // Assuming the job is complete when data from all stations is collected.
        return this.data.size() >= 3; // Adjust this condition as necessary.
    }

    public String getCustomerId() {
        return customerId;
    }

    public List<String> getData() {
        return data;
    }
}
