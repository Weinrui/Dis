package com.project2.DataCollectionReceiver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DataCollectionReceiverApplicationTests {

	@Test
	void contextLoads() {
	}

}
