package com.project2.PDFGenerator.services;

import com.project2.PDFGenerator.entity.Customer;
import com.project2.PDFGenerator.repository.CustomerRepository;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.FileOutputStream;
import java.io.IOException;

@Service
public class PdfGeneratorService {

    @Autowired
    private CustomerRepository customerRepository;

    @RabbitListener(queues = "pdfGeneratorQueue")
    public void generatePdf(String message) {
        String[] parts = message.split(":");
        String customerId = parts[1];
        String data = parts[2];

        Customer customer = customerRepository.findByCustomerId(customerId);

        if (customer != null) {
            Document document = new Document();
            try {
                String filePath = "invoices/invoice_" + customerId + ".pdf";
                PdfWriter.getInstance(document, new FileOutputStream(filePath));
                document.open();
                document.add(new Paragraph("Invoice for Customer ID: " + customerId));
                document.add(new Paragraph("Name: " + customer.getName()));
                document.add(new Paragraph("Email: " + customer.getEmail()));
                document.add(new Paragraph("Collected Data:"));
                document.add(new Paragraph(data));
                document.close();
            } catch (DocumentException | IOException e) {
                e.printStackTrace();
            }
        } else {
            System.out.println("Customer not found for ID: " + customerId);
        }
    }
}
