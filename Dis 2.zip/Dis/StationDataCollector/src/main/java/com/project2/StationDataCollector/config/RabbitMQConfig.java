package com.project2.StationDataCollector.config;

import org.springframework.amqp.core.Queue;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {

    @Bean
    public Queue stationDataQueue() {
        return new Queue("stationDataQueue");
    }

    @Bean
    public Queue dataCollectionReceiverQueue() {
        return new Queue("dataCollectionReceiverQueue");
    }
}

