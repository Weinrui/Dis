package com.project2.StationDataCollector.controller;

import com.project2.StationDataCollector.entity.StationData;
import com.project2.StationDataCollector.repository.StationDataRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/station-data")
public class StationDataController {

    @Autowired
    private StationDataRepository stationDataRepository;

    @GetMapping("/customer/{customerId}")
    public List<StationData> getStationDataForCustomer(@PathVariable String customerId) {
        return stationDataRepository.findByCustomerId(customerId);
    }
}
