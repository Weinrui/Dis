package com.project2.StationDataCollector.entity;
import jakarta.persistence.*;

@Entity
public class StationData {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String customerId;
    private String stationId;
    private Double kWhUsed;


    public StationData() {
    }

    public StationData(String customerId, String stationId, Double kWhUsed) {
        this.customerId = customerId;
        this.stationId = stationId;
        this.kWhUsed = kWhUsed;
    }
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getStationId() {
        return stationId;
    }

    public void setStationId(String stationId) {
        this.stationId = stationId;
    }

    public Double getkWhUsed() {
        return kWhUsed;
    }

    public void setkWhUsed(Double kWhUsed) {
        this.kWhUsed = kWhUsed;
    }

}
