package com.project2.StationDataCollector.repository;

import com.project2.StationDataCollector.entity.StationData;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StationDataRepository extends JpaRepository<StationData, Long> {

    List<StationData> findByCustomerId(String customerId);

}
