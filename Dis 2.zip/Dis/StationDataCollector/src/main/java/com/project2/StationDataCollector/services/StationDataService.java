package com.project2.StationDataCollector.services;

import com.project2.StationDataCollector.entity.StationData;
import com.project2.StationDataCollector.repository.StationDataRepository;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StationDataService {

    @Autowired
    private StationDataRepository stationDataRepository;

    @Autowired
    private RabbitTemplate rabbitTemplate;

    @RabbitListener(queues = "stationDataQueue")
    public void collectStationData(String message) {
        String[] parts = message.split(":");
        String stationId = parts[0];
        String customerId = parts[1];

        // Simulate data collection process
        double kWhUsed = Math.random() * 100; // For example purposes

        StationData stationData = new StationData(customerId, stationId, kWhUsed);
        stationDataRepository.save(stationData);

        // After saving, send the data to the dataCollectionReceiverQueue
        String collectedDataMessage = "data:" + customerId + ":" + stationId + ":" + kWhUsed;
        rabbitTemplate.convertAndSend("dataCollectionReceiverQueue", collectedDataMessage);
    }
}
