package com.project2.StationDataCollector;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StationDataCollectorApplicationTests {

	@Test
	void contextLoads() {
	}

}
