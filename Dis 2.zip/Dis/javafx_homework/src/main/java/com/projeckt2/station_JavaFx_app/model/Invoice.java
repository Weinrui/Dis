package com.projeckt2.station_JavaFx_app.model;

import javafx.scene.control.Button;

public class Invoice {
    private String customerId;
    private Button viewInvoiceButton;

    public Invoice(String customerId) {
        this.customerId = customerId;
        this.viewInvoiceButton = new Button("View Invoice");
        this.viewInvoiceButton.setOnAction(e -> openInvoice());
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public Button getViewInvoiceButton() {
        return viewInvoiceButton;
    }

    public void setViewInvoiceButton(Button viewInvoiceButton) {
        this.viewInvoiceButton = viewInvoiceButton;
    }

    private void openInvoice() {
        // Open the invoice in a browser or PDF viewer
        System.out.println("Opening invoice for customer: " + customerId);
        // Actual implementation to open the PDF file or URL goes here
    }
}
