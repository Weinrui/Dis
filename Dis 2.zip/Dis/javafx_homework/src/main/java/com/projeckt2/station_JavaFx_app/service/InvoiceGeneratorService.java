package com.projeckt2.station_JavaFx_app.service;

import com.projeckt2.station_JavaFx_app.model.Invoice;
import org.apache.hc.client5.http.classic.methods.HttpGet;
import org.apache.hc.client5.http.classic.methods.HttpPost;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.apache.hc.core5.http.io.entity.StringEntity;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class InvoiceGeneratorService {
    private static final String BASE_URL = "http://localhost:8080/invoices/";

    public void generateInvoice(String customerId) throws Exception {
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpPost httpPost = new HttpPost(BASE_URL + customerId);
            httpPost.setEntity(new StringEntity(""));
            try (CloseableHttpResponse response = httpClient.execute(httpPost)) {
                if (response.getCode() != 200) {
                    throw new Exception("Failed to start invoice generation.");
                }
            }
        }
    }

    public List<Invoice> checkInvoiceAvailability(String customerId) throws Exception {
        List<Invoice> invoices = new ArrayList<>();
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpGet httpGet = new HttpGet(BASE_URL + customerId);
            try (CloseableHttpResponse response = httpClient.execute(httpGet)) {
                if (response.getCode() == 200) {
                    invoices.add(new Invoice(customerId));
                } else {
                    throw new Exception("Invoice not available.");
                }
            }
        }
        return invoices;
    }
}
