package com.project2.DataCollectionDispatcher;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataCollectionDispatcherApplication {
	public static void main(String[] args) {
		SpringApplication.run(DataCollectionDispatcherApplication.class, args);
	}
}
