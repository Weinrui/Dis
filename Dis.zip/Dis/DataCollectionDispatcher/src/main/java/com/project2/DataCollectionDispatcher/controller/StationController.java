package com.project2.DataCollectionDispatcher.controller;

import com.project2.DataCollectionDispatcher.entity.Station;
import com.project2.DataCollectionDispatcher.repository.StationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/stations")
public class StationController {

    @Autowired
    private StationRepository stationRepository;

    @PostMapping
    public ResponseEntity<Station> addStation(@RequestBody Station station) {
        Station savedStation = stationRepository.save(station);
        return new ResponseEntity<>(savedStation, HttpStatus.CREATED);
    }
}
