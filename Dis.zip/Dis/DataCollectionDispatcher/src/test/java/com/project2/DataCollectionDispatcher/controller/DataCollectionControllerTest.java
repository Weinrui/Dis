package com.project2.DataCollectionDispatcher.controller;

import com.project2.DataCollectionDispatcher.entity.Station;
import com.project2.DataCollectionDispatcher.repository.StationRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;


import static org.assertj.core.api.AssertionsForInterfaceTypes.assertThat;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;


@ExtendWith(MockitoExtension.class)
class CustomersControllerTest {



    @Mock
    private StationRepository mockedStationRepository;

    @InjectMocks
    private StationController StationController;


    @Test
    void testGetCustomers(){
        //Arrange
        when(mockedStationRepository.findAll())
                .thenReturn(List.of());
        /*
        CustomerEntity customerEntity =new CustomerEntity();
        customerEntity.setFirstname("abc");
        customerEntity.setLastName("cde");

        */
        //Act
        List<Station> stations = stationController.getCustomers("","");

        //Assert
        assertThat(customers).isEmpty();


    }



}