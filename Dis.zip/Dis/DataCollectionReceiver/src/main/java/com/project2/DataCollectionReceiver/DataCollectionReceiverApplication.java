package com.project2.DataCollectionReceiver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DataCollectionReceiverApplication {
	public static void main(String[] args) {
		SpringApplication.run(DataCollectionReceiverApplication.class, args);
	}
}
