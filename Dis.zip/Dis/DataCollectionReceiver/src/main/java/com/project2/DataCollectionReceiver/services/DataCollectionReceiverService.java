package com.project2.DataCollectionReceiver.services;

import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DataCollectionReceiverService {

    @Autowired
    private RabbitTemplate rabbitTemplate;

    private Long currentCustomerId;
    private Double currentKwh;

    public void processCustomerId(Long customerId) {
        currentCustomerId = customerId;
        sendMessageIfReady();
    }

    public void processKwh(Double kwh) {
        currentKwh = kwh;
        sendMessageIfReady();
    }

    private void sendMessageIfReady() {
        if (currentCustomerId != null && currentKwh != null) {
            String message = currentCustomerId + "," + currentKwh;
            rabbitTemplate.convertAndSend("pdfGeneratorQueue", message);
            // Reset after sending
            currentCustomerId = null;
            currentKwh = null;
        }
    }
}
