package com.project2.PDFGenerator.listener;

import com.project2.PDFGenerator.services.PdfGeneratorService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PdfGeneratorListener {

    private static final Logger log = LoggerFactory.getLogger(PdfGeneratorListener.class);

    @Autowired
    private PdfGeneratorService pdfGeneratorService;

    @RabbitListener(queues = "pdfGeneratorQueue")
    public void receiveMessage(String message) {
        log.info("Received message: {}", message);
        String[] parts = message.split(",");
        Long customerId = Long.parseLong(parts[0]);
        Double kwh = Double.parseDouble(parts[1]);
        pdfGeneratorService.generateInvoice(customerId, kwh);
    }
}
