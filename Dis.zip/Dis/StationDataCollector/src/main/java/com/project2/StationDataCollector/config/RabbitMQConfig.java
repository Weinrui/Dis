package com.project2.StationDataCollector.config;

import org.springframework.amqp.core.Queue;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {

    public static final String STATION_DATA_QUEUE_NAME = "stationDataQueue";
    public static final String KWH_QUEUE = "kwhQueue";

    @Bean
    public Queue stationDataQueue() {
        return new Queue(STATION_DATA_QUEUE_NAME, true);
    }

    @Bean
    public Queue kwhQueue() {
        return new Queue(KWH_QUEUE, true);
    }
}
