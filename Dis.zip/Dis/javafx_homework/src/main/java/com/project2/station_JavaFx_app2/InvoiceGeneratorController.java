package com.project2.station_JavaFx_app2;

import com.project2.station_JavaFx_app2.model.Invoice;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.io.IOException;
public class InvoiceGeneratorController {

    @FXML
    private TextField customerIdField;

    @FXML
    private TableView<Invoice> invoiceTable;

    @FXML
    private TableColumn<Invoice, Long> customerIdColumn;

    @FXML
    private TableColumn<Invoice, Button> downloadColumn;

    private ObservableList<Invoice> invoiceData = FXCollections.observableArrayList();
    private static final Logger logger = Logger.getLogger(InvoiceGeneratorController.class.getName());

    @FXML
    public void initialize() {
        customerIdColumn.setCellValueFactory(new PropertyValueFactory<>("customerId"));
        downloadColumn.setCellFactory(param -> new TableCell<Invoice, Button>() {
            private final Button downloadButton = new Button("Download");

            @Override
            protected void updateItem(Button item, boolean empty) {
                super.updateItem(item, empty);
                if (empty) {
                    setGraphic(null);
                } else {
                    setGraphic(downloadButton);
                    downloadButton.setOnAction(event -> downloadInvoice(getTableView().getItems().get(getIndex()).getCustomerId().toString()));
                }
            }
        });
        invoiceTable.setItems(invoiceData);
    }

    @FXML
    public void generateInvoice(ActionEvent event) {
        String customerId = customerIdField.getText();
        if (customerId == null || customerId.isEmpty()) {
            showAlert("Error", "Customer ID cannot be empty");
            return;
        }
        logger.log(Level.INFO, "Generating invoice for customer ID: {0}", customerId);
        sendCustomerIdToSpringBootApp(customerId);
    }

    private void sendCustomerIdToSpringBootApp(String customerId) {
        try {
            URL url = new URL("http://localhost:8081/invoices/" + customerId);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            logger.log(Level.INFO, "Response from Spring Boot: {0}", response.toString());
            showAlert("Success", response.toString());
            fetchInvoices(customerId);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to send customer ID", e);
            showAlert("Error", "Failed to send customer ID");
        }
    }

    private void fetchInvoices(String customerId) {
        try {
            URL url = new URL("http://localhost:8081/invoices/" + customerId);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");

            BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String inputLine;
            StringBuilder response = new StringBuilder();
            while ((inputLine = in.readLine()) != null) {
                response.append(inputLine);
            }
            in.close();

            logger.log(Level.INFO, "Fetched invoices response: {0}", response.toString());
            List<Invoice> invoices = parseInvoices(response.toString(), customerId);
            invoiceData.setAll(invoices);
        } catch (Exception e) {
            logger.log(Level.SEVERE, "Failed to fetch invoices", e);
            showAlert("Error", "Failed to fetch invoices");
        }
    }

    private List<Invoice> parseInvoices(String response, String customerId) {
        // Convert customerId to Long
        Long customerIdLong = Long.parseLong(customerId);
        // Implement parsing logic based on your JSON response structure
        // Example assuming response is a single string for invoice details
        logger.log(Level.INFO, "Parsing invoices for customer ID: {0} with response: {1}", new Object[]{customerId, response});
        return List.of(new Invoice(customerIdLong, response)); // Replace with actual parsing logic
    }

    private void downloadInvoice(String customerId) {
        try {
            // Construct the path to the invoice file
            Path sourcePath = Paths.get(System.getProperty("user.dir"), "../invoices", "invoice_" + customerId + ".pdf");

            // Get the user's home directory and construct the Downloads path
            String userHome = System.getProperty("user.home");
            Path destinationPath = Paths.get(userHome, "Downloads", "downloaded_invoice_" + customerId + ".pdf");

            // Copy the file to the destination path
            Files.copy(sourcePath, destinationPath, StandardCopyOption.REPLACE_EXISTING);

            logger.log(Level.INFO, "Invoice downloaded for customer ID: {0}", customerId);
            showAlert("Success", "Invoice downloaded for customer ID: " + customerId + " in Downloads folder");
        } catch (IOException e) {
            logger.log(Level.SEVERE, "Failed to download invoice", e);
            showAlert("Error", "Failed to download invoice");
        }
    }


    private void showAlert(String title, String content) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }
}
