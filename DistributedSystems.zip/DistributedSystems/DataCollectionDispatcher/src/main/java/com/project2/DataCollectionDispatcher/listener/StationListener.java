package com.project2.DataCollectionDispatcher.listener;

import com.project2.DataCollectionDispatcher.config.RabbitMQConfig;
import com.project2.DataCollectionDispatcher.services.StationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class StationListener {
    private static final Logger log = LoggerFactory.getLogger(StationListener.class);

    @Autowired
    private StationService stationService;

    private Long messageId;

    @RabbitListener(queues = RabbitMQConfig.INVOICE_QUEUE_NAME)
    public void handleInvoiceMessage(Long message) {
        log.info("Received message from invoice queue: {}", message);
        messageId = message;
        // Start the data gathering job when a message is received in the invoice queue
        stationService.startDataGatheringJob(messageId);
    }

    @RabbitListener(queues = RabbitMQConfig.STATION_DATA_QUEUE_NAME)
    public void handleStationDataMessage(String message) {
        log.info("Received message from station data queue: {}", message);
        // Add logic to process the message here
    }

}
