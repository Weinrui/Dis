package com.project2.PDFGenerator.services;

import com.project2.PDFGenerator.entity.Customer;
import com.project2.PDFGenerator.repository.CustomerRepository;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

@Service
public class PdfGeneratorService {

    @Autowired
    private CustomerRepository customerRepository;

    public void generateInvoice(Long customerId, Double kwh) {
        Customer customer = customerRepository.findById(customerId).orElseThrow(() -> new RuntimeException("Customer not found"));

        Document document = new Document();
        try {
            String invoiceDirectory = "../invoices";
            File dir = new File(invoiceDirectory);
            if (!dir.exists()) {
                dir.mkdirs();
            }

            String filePath = invoiceDirectory + "/invoice_" + customerId + ".pdf";
            PdfWriter.getInstance(document, new FileOutputStream(filePath));
            document.open();

            document.add(new Paragraph("Invoice for Customer ID: " + customerId));
            document.add(new Paragraph("First Name: " + customer.getFirstname()));
            document.add(new Paragraph("Last Name: " + customer.getLastname()));
            document.add(new Paragraph("Collected kwh: " + kwh));

            document.close();
        } catch (DocumentException | IOException e) {
            e.printStackTrace();
        }
    }
}
