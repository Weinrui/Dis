package com.project2.DataCollectionDispatcher;

import com.project2.DataCollectionDispatcher.config.RabbitMQConfig;
import com.project2.DataCollectionDispatcher.entity.Station;
import com.project2.DataCollectionDispatcher.repository.StationRepository;
import com.project2.DataCollectionDispatcher.services.StationService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.amqp.rabbit.core.RabbitTemplate;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.*;

public class StationServiceTest {

    // Mocking the dependencies of StationService
    @Mock
    private StationRepository stationRepository;

    @Mock
    private RabbitTemplate rabbitTemplate;

    // Injecting the mocks into StationService instance
    @InjectMocks
    private StationService stationService;

    // Setting up the mock objects before each test
    @BeforeEach
    public void setUp() {
        // Initializes fields annotated with @Mock and injects them into fields annotated with @InjectMocks
        MockitoAnnotations.openMocks(this);
    }

    // Test method for startDataGatheringJob
    @Test
    public void testStartDataGatheringJob() {
        // Sample messageId for the test
        Long messageId = 123L;

        // Preparing mock data for the stations
        Station station1 = new Station();
        Station station2 = new Station();
        List<Station> stations = Arrays.asList(station1, station2);

        // Mocking the behavior of stationRepository to return the prepared station list
        when(stationRepository.findAll()).thenReturn(stations);

        // Calling the method to be tested
        stationService.startDataGatheringJob(messageId);

        // Verifying that stationRepository.findAll() was called exactly once
        verify(stationRepository, times(1)).findAll();

        // Verifying that rabbitTemplate.convertAndSend() was called twice with STATION_DATA_QUEUE_NAME and messageId
        verify(rabbitTemplate, times(2)).convertAndSend(RabbitMQConfig.STATION_DATA_QUEUE_NAME, messageId);

        // Verifying that rabbitTemplate.convertAndSend() was called once with DATA_COLLECTION_RECEIVER_QUEUE_NAME and messageId
        verify(rabbitTemplate, times(1)).convertAndSend(RabbitMQConfig.DATA_COLLECTION_RECEIVER_QUEUE_NAME, messageId);
    }
}
