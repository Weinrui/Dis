package com.project2.SpringBootApp;
import com.project2.SpringBootApp.config.RabbitMQConfig;
import com.project2.SpringBootApp.services.InvoiceService;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.ResponseEntity;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@SpringBootTest
class SpringBootAppApplicationTests {

	@MockBean
	private RabbitTemplate rabbitTemplate;

	@Autowired
	private InvoiceService invoiceService;

	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}
	@Test
	public void testStartInvoiceGeneration() {
		// Define a customerId variable with value "12345"
		String customerId = "12345";

		// Call the startInvoiceGeneration method of invoiceService with customerId
		invoiceService.startInvoiceGeneration(customerId);

		// Verify that the convertAndSend method of rabbitTemplate is called exactly once with the expected arguments
		verify(rabbitTemplate, times(1)).convertAndSend(eq(RabbitMQConfig.INVOICE_QUEUE_NAME), eq(customerId));
	}

	@Test
	public void testProcessMessage() {
		// Define a message variable with value "testMessage"
		String message = "testMessage";
		// Define a messageCount variable with value 1
		int messageCount = 1;

		// Record the current time as startTime
		long startTime = System.currentTimeMillis();
		// Call the processMessage method of invoiceService with message and messageCount
		invoiceService.processMessage(message, messageCount);
		// Record the current time as endTime
		long endTime = System.currentTimeMillis();

		// Assert that the processMessage method's execution time is greater than or equal to message length * 1000 milliseconds
		assertEquals(true, (endTime - startTime) >= (message.length() * 1000L));
	}

	@Test
	public void testGetInvoiceWhenInvoiceAvailable() {
		// Define a customerId variable with value "1"
		String customerId = "1";

		// Create a spy object of invoiceService to partially mock it
		InvoiceService spyService = spy(invoiceService);
		// Mock the isInvoiceAvailable method to return true when called with customerId
		doReturn(true).when(spyService).isInvoiceAvailable(customerId);

		// Call the getInvoice method of spyService with customerId and store the response
		ResponseEntity<?> response = spyService.getInvoice(customerId);

		// Assert that the response status code is 200
		assertEquals(200, response.getStatusCodeValue());
		// Assert that the response body is "Invoice available to be Downloaded"
		assertEquals("Invoice available to be Downloaded", response.getBody());
	}

	@Test
	public void testGetInvoiceWhenInvoiceNotAvailable() {
		// Define a customerId variable with value "12345"
		String customerId = "12345";

		// Create a spy object of invoiceService to partially mock it
		InvoiceService spyService = spy(invoiceService);
		// Mock the isInvoiceAvailable method to return false when called with customerId
		doReturn(false).when(spyService).isInvoiceAvailable(customerId);

		// Call the getInvoice method of spyService with customerId and store the response
		ResponseEntity<?> response = spyService.getInvoice(customerId);

		// Assert that the response status code is 404
		assertEquals(404, response.getStatusCodeValue());
		// Assert that the response body is "Invoice not available yet"
		assertEquals("Invoice not available yet", response.getBody());
	}
}