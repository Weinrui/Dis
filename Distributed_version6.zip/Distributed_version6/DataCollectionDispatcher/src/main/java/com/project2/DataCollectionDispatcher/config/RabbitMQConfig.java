package com.project2.DataCollectionDispatcher.config;

import org.springframework.amqp.core.Queue;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {

    public static final String INVOICE_QUEUE_NAME = "invoice";
    public static final String STATION_DATA_QUEUE_NAME = "stationDataQueue";
    public static final String DATA_COLLECTION_RECEIVER_QUEUE_NAME = "dataCollectionReceiverQueue";

    @Bean
    public Queue invoice() {
        return new Queue(INVOICE_QUEUE_NAME, true);
    }

    @Bean
    public Queue stationDataQueue() {
        return new Queue(STATION_DATA_QUEUE_NAME, true);  // Ändern Sie 'false' zu 'true' wenn die Warteschlange auf dem Server 'durable' ist
    }

    @Bean
    public Queue dataCollectionReceiverQueue() {
        return new Queue(DATA_COLLECTION_RECEIVER_QUEUE_NAME, true);
    }



}
