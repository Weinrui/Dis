package com.project2.SpringBootApp.config;

import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.connection.CachingConnectionFactory;
import org.springframework.amqp.rabbit.connection.ConnectionFactory;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RabbitMQConfig {

    public static final String INVOICE_QUEUE_NAME = "invoice";

    @Bean
    public Queue invoice() {
        return new Queue(INVOICE_QUEUE_NAME, true);
    }


}
